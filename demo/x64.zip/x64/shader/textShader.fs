#version 430

uniform vec4 TextColor;

out vec4 FragColor;

void main() {
    FragColor = TextColor;
}
