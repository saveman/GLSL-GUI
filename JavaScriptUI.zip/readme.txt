Test it in IE with no problem.

It has compatiable problem in Google Chrome.

Mention my work if you want to use it.